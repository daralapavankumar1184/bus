package com.masai.exception;

public class DateTimeException extends Exception{

	
	public DateTimeException() {
		// TODO Auto-generated constructor stub
	}
	
	
	public DateTimeException(String mes) {
		
		super(mes);
		
	}
	
	
}
